# -*- coding: utf-8 -*-
import product_category
import product_uom
import res_partner
import product_supplierinfo
import product
